package exercises.easier.part1;

public class Rectangle {
  public double width, height;

  public double getArea() {
    return(width * height);
  }
}