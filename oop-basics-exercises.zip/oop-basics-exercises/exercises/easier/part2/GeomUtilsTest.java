package exercises.easier.part2;

public class GeomUtilsTest {
  public static void main(String[] args) {
    System.out.println("Hypotenuse for legs 3,4 = " + GeomUtils.hypotenuse(3, 4));
    System.out.println("Hypotenuse for legs 5,12 = " + GeomUtils.hypotenuse(5, 12));
    System.out.println("Hypotenuse for legs 8,15 = " + GeomUtils.hypotenuse(8, 15));
    System.out.println("Hypotenuse for legs 1,1 = " + GeomUtils.hypotenuse(1, 1));
  }
}
