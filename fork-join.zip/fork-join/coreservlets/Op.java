package coreservlets;

public interface Op {
  String runOp();
}
